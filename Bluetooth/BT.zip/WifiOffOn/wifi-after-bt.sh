#!/bin/bash
timeout=30
count=0
while true
do
    firmware=$(system_profiler SPBluetoothDataType | grep "Firmware Version:")
    case "$firmware" in
	    # Firmware injected after powerOff or from Windows
	    *"6.4354 (6.1)"*)	
            break
            ;;
	    # Firmware present after booting from Linux
	    *"7.4354 (6.1)"*)
            break
            ;;
    esac
    sleep 1
    count=$((count + 1))
    if [ "$count" -ge "$timeout" ]; then
        echo "Bluetooth firmware not detected after ${timeout} seconds."
        exit 1
    fi
done
# security
sleep 1
networksetup -setairportpower en1 on
exit 0
